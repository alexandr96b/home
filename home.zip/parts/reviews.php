<section class="b-reviews">
	<div class="container">
		<div class="b-title">Was unsere Kunden sagen</div>
		<script src="https://apps.elfsight.com/p/platform.js" defer></script>
		<div class="elfsight-app-d46d827b-bee6-408e-aed3-ffa0a7b03044"></div>
	</div>
</section>